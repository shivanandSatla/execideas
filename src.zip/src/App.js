import logo from './logo.svg';
import './App.css';
import UsersList from './Components/UsersList'
function App() {
  return (
    <div className="App">
      <UsersList />
    </div>
  );
}

export default App;
